using System.Net.Mime;
using System.Security.Claims;
using Jellyfin.Plugin.SuggestionBoard.Models;
using Jellyfin.Plugin.SuggestionBoard.Storage;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Jellyfin.Plugin.SuggestionBoard.Api;

[ApiController]
[RequestSizeLimit(24576)]
[ServiceFilter(typeof(Jellyfin.Plugin.SuggestionBoard.Security.BoardSecurityFilter))]
[Authorize]
[Route("SuggestionBoard")]
[Produces(MediaTypeNames.Application.Json)]
public sealed class SuggestionBoardController :
    ControllerBase
{
    private const string AdministratorRole =
        "Administrator";

    private readonly SuggestionStore _store;

    public SuggestionBoardController(
        SuggestionStore store)
    {
        _store = store;
    }

    [AllowAnonymous]
    [HttpGet("Page")]
    [Produces("text/html")]
    public IActionResult GetPage()
    {
        const string resourceName =
            "Jellyfin.Plugin.SuggestionBoard.Web.suggestionboard.html";

        using var stream =
            typeof(Plugin)
                .Assembly
                .GetManifestResourceStream(
                    resourceName);

        if (stream is null)
        {
            return NotFound();
        }

        using var reader =
            new StreamReader(stream);

        return Content(
            reader.ReadToEnd(),
            "text/html; charset=utf-8");
    }

    [AllowAnonymous]
    [HttpGet("client.js")]
    [Produces("application/javascript")]
    public IActionResult GetClientScript()
    {
        const string resourceName =
            "Jellyfin.Plugin.SuggestionBoard.Web.client.js";

        using var stream =
            typeof(Plugin)
                .Assembly
                .GetManifestResourceStream(
                    resourceName);

        if (stream is null)
        {
            return NotFound();
        }

        using var reader =
            new StreamReader(stream);

        return Content(
            reader.ReadToEnd(),
            "application/javascript; charset=utf-8");
    }

    [HttpGet("items")]
    public async Task<ActionResult<
        IReadOnlyList<SuggestionResponse>>> GetItems(
        [FromQuery] string? sort,
        [FromQuery] int startIndex = 0,
        [FromQuery] int limit = 100,
        CancellationToken cancellationToken = default)
    {
        if (startIndex < 0 || limit < 1 || limit > 100) return BadRequest();
        var userKey = GetCurrentUserKey();

        var items = await _store.GetPageAsync(sort, startIndex, limit, cancellationToken).ConfigureAwait(false);
        return Ok(items.Select(item => ToResponse(item, userKey)).ToList());
    }

    [HttpPost("items")]
    public async Task<ActionResult<SuggestionResponse>> Create(
        [FromBody] CreateSuggestionRequest request,
        CancellationToken cancellationToken)
    {
        var title =
            request.Title?.Trim()
            ?? string.Empty;

        var description =
            request.Description?.Trim()
            ?? string.Empty;

        if (title.Length is < 2 or > 120)
        {
            return BadRequest(new
            {
                message =
                    "Der Titel muss zwischen 2 und 120 Zeichen lang sein."
            });
        }

        if (description.Length is < 2 or > 4000)
        {
            return BadRequest(new
            {
                message =
                    "Die Beschreibung muss zwischen 2 und 4000 Zeichen lang sein."
            });
        }

        var userKey =
            GetCurrentUserKey();

        var item =
            await _store
                .AddAsync(
                    title,
                    description,
                    GetCurrentUserName(),
                    userKey,
                    cancellationToken)
                .ConfigureAwait(false);

        return Ok(
            ToResponse(
                item,
                userKey));
    }

    [HttpPost("items/{id:guid}/vote")]
    public async Task<ActionResult<SuggestionResponse>> ToggleVote(
        [FromRoute] Guid id,
        CancellationToken cancellationToken)
    {
        var userKey =
            GetCurrentUserKey();

        var item =
            await _store
                .ToggleVoteAsync(
                    id,
                    userKey,
                    cancellationToken)
                .ConfigureAwait(false);

        if (item is null)
        {
            return NotFound();
        }

        if (item.IsClosed)
        {
            return Conflict(new
            {
                message =
                    "Geschlossene Vorschläge können nicht mehr bewertet werden."
            });
        }

        return Ok(
            ToResponse(
                item,
                userKey));
    }

    [HttpPut("items/{id:guid}/status")]
    public async Task<ActionResult<SuggestionResponse>> SetStatus(
        [FromRoute] Guid id,
        [FromBody] SetSuggestionStatusRequest request,
        CancellationToken cancellationToken)
    {
        if (!User.IsInRole(AdministratorRole))
        {
            return Forbid();
        }

        var item =
            await _store
                .SetClosedAsync(
                    id,
                    request.IsClosed,
                    cancellationToken)
                .ConfigureAwait(false);

        if (item is null)
        {
            return NotFound();
        }

        return Ok(
            ToResponse(
                item,
                GetCurrentUserKey()));
    }

    [HttpDelete("items/{id:guid}")]
    public async Task<IActionResult> Delete(
        [FromRoute] Guid id,
        CancellationToken cancellationToken)
    {
        if (!User.IsInRole(AdministratorRole))
        {
            return Forbid();
        }

        var removed =
            await _store
                .DeleteAsync(
                    id,
                    cancellationToken)
                .ConfigureAwait(false);

        return removed
            ? NoContent()
            : NotFound();
    }

    private SuggestionResponse ToResponse(
        SuggestionRecord item,
        string userKey)
    {
        return new SuggestionResponse
        {
            Id = item.Id,
            Title = item.Title,
            Description = item.Description,
            CreatedBy = User.IsInRole(AdministratorRole) ? item.CreatedBy : "Anonym",
            CreatedAtUtc = item.CreatedAtUtc,
            IsClosed = item.IsClosed,
            VoteCount = item.VoterKeys.Count,
            HasVoted = item.VoterKeys.Any(
                value => string.Equals(
                    value,
                    userKey,
                    StringComparison.OrdinalIgnoreCase)),
            IsOwnSuggestion = string.Equals(
                item.CreatedByUserKey,
                userKey,
                StringComparison.OrdinalIgnoreCase)
        };
    }

    private string GetCurrentUserKey()
    {
        // Validated before model binding by BoardSecurityFilter; no name fallback.
        return (string)HttpContext.Items[Security.BoardSecurityFilter.UserKeyItem]!;
    }

    private string GetCurrentUserName()
    {
        return User.Identity?.Name
               ?? User.FindFirst(
                   ClaimTypes.Name)?.Value
               ?? User.FindFirst("name")?.Value
               ?? "Unbekannt";
    }
}
