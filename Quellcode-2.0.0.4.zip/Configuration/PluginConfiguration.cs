using MediaBrowser.Model.Plugins;

namespace Jellyfin.Plugin.SuggestionBoard.Configuration;

public sealed class PluginConfiguration : BasePluginConfiguration
{
}
