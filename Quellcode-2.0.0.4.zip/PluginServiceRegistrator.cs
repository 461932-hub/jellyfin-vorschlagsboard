using Jellyfin.Plugin.SuggestionBoard.Storage;
using MediaBrowser.Controller;
using MediaBrowser.Controller.Plugins;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.DependencyInjection;

namespace Jellyfin.Plugin.SuggestionBoard;

public sealed class PluginServiceRegistrator :
    IPluginServiceRegistrator
{
    public void RegisterServices(
        IServiceCollection services,
        IServerApplicationHost applicationHost)
    {
        services.AddSingleton<SuggestionStore>();
        services.AddSingleton<Security.BoardRequestLimiter>();
        services.AddTransient<Security.BoardSecurityFilter>();
        services.AddHostedService<SuggestionBoardEntryPoint>();
        services.AddSingleton<IStartupFilter, WebInjectionStartupFilter>();
    }
}
