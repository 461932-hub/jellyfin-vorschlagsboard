using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Jellyfin.Plugin.SuggestionBoard.Storage;

namespace Jellyfin.Plugin.SuggestionBoard.Security;

public sealed class BoardSecurityFilter(BoardRequestLimiter limiter) : IAsyncResourceFilter, IExceptionFilter
{
    public const string UserKeyItem = "SuggestionBoard.ValidatedUserId";
    public async Task OnResourceExecutionAsync(ResourceExecutingContext context, ResourceExecutionDelegate next)
    {
        var http = context.HttpContext;
        http.Response.Headers["X-Content-Type-Options"] = "nosniff";
        http.Response.Headers["X-Frame-Options"] = "SAMEORIGIN";
        http.Response.Headers["Referrer-Policy"] = "no-referrer";
        http.Response.Headers["Content-Security-Policy"] = "frame-ancestors 'self'; object-src 'none'; base-uri 'self'";
        if (context.ActionDescriptor.EndpointMetadata.OfType<IAllowAnonymous>().Any()) { await next(); return; }
        http.Response.Headers.CacheControl = "no-store";
        if (!Guid.TryParse(http.User.FindFirst("Jellyfin-UserId")?.Value, out var id) || id == Guid.Empty)
        {
            context.Result = new ObjectResult(new { message = "Eine persönliche Jellyfin-Anmeldung ist erforderlich." }) { StatusCode = 403 };
            return;
        }
        var user = "user:" + id.ToString("N");
        http.Items[UserKeyItem] = user;
        var write = !HttpMethods.IsGet(http.Request.Method) && !HttpMethods.IsHead(http.Request.Method);
        var create = HttpMethods.IsPost(http.Request.Method) && http.Request.Path.Value?.EndsWith("/items", StringComparison.OrdinalIgnoreCase) == true;
        using var lease = limiter.TryEnter(user, write, create);
        if (lease is null)
        {
            http.Response.Headers.RetryAfter = "60";
            context.Result = new ObjectResult(new { message = "Zu viele Anfragen. Bitte in einer Minute erneut versuchen." }) { StatusCode = 429 };
            return;
        }
        if (!write) { await next(); return; }
        // Bound input before MVC deserializes it, including chunked requests.
        // Jellyfin's global exception middleware would otherwise map a Kestrel
        // body-size exception to HTTP 500 instead of a controlled rejection.
        const int maxBody = 24576;
        if (http.Request.ContentLength > maxBody) { context.Result = new StatusCodeResult(413); return; }
        using var body = new MemoryStream();
        var bytes = new byte[4096];
        try
        {
            int read;
            while ((read = await http.Request.Body.ReadAsync(bytes, http.RequestAborted)) > 0)
            {
                if (body.Length + read > maxBody) { context.Result = new StatusCodeResult(413); return; }
                await body.WriteAsync(bytes.AsMemory(0, read), http.RequestAborted);
            }
        }
        catch (BadHttpRequestException error) when (error.StatusCode == 413)
        { context.Result = new StatusCodeResult(413); return; }
        body.Position = 0;
        var original = http.Request.Body; http.Request.Body = body;
        try { await next(); }
        finally { http.Request.Body = original; }
    }
    public void OnException(ExceptionContext context)
    {
        if (context.Exception is not BoardStoreException failure) return;
        context.Result = new ObjectResult(new { message = failure.Message }) { StatusCode = failure.StatusCode };
        context.ExceptionHandled = true;
    }
}
