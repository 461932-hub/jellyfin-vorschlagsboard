namespace Jellyfin.Plugin.SuggestionBoard.Security;

// Process-wide limits, not browser-side limits. No unbounded partition cache or queue.
public sealed class BoardRequestLimiter
{
    private sealed class Window
    {
        public DateTimeOffset Minute, Hour;
        public int Reads, Writes, Creates, HourCreates, Active;
    }
    private readonly object _gate = new();
    private readonly Dictionary<string, Window> _users = new(StringComparer.Ordinal);
    private readonly TimeProvider _clock;
    private DateTimeOffset _globalMinute;
    private int _globalRequests, _active;
    public BoardRequestLimiter() : this(TimeProvider.System) { }
    public BoardRequestLimiter(TimeProvider clock) => _clock = clock;

    public IDisposable? TryEnter(string user, bool write, bool create)
    {
        lock (_gate)
        {
            var now = _clock.GetUtcNow();
            if (now - _globalMinute >= TimeSpan.FromMinutes(1)) { _globalMinute = now; _globalRequests = 0; }
            if (_active >= 16 || _globalRequests >= 600) return null;
            if (!_users.TryGetValue(user, out var window))
            {
                if (_users.Count >= 4096)
                {
                    foreach (var key in _users.Where(x => x.Value.Active == 0 && now - x.Value.Hour >= TimeSpan.FromHours(1)).Select(x => x.Key).ToArray()) _users.Remove(key);
                    if (_users.Count >= 4096) return null;
                }
                window = new Window { Minute = now, Hour = now };
                _users.Add(user, window);
            }
            if (now - window.Minute >= TimeSpan.FromMinutes(1)) { window.Minute = now; window.Reads = window.Writes = window.Creates = 0; }
            if (now - window.Hour >= TimeSpan.FromHours(1)) { window.Hour = now; window.HourCreates = 0; }
            if (window.Active >= 2 || (write ? window.Writes >= 30 : window.Reads >= 120)
                || create && (window.Creates >= 5 || window.HourCreates >= 20)) return null;
            _globalRequests++; _active++; window.Active++;
            if (write) window.Writes++; else window.Reads++;
            if (create) { window.Creates++; window.HourCreates++; }
            return new Lease(this, window);
        }
    }
    private sealed class Lease(BoardRequestLimiter owner, Window window) : IDisposable
    {
        private int _disposed;
        public void Dispose()
        {
            if (Interlocked.Exchange(ref _disposed, 1) != 0) return;
            lock (owner._gate) { owner._active--; window.Active--; }
        }
    }
}
