using Jellyfin.Plugin.SuggestionBoard.Configuration;
using MediaBrowser.Common.Configuration;
using MediaBrowser.Common.Plugins;
using MediaBrowser.Model.Plugins;
using MediaBrowser.Model.Serialization;

namespace Jellyfin.Plugin.SuggestionBoard;

public sealed class Plugin :
    BasePlugin<PluginConfiguration>,
    IHasWebPages
{
    private static readonly Guid PluginId =
        Guid.Parse("7b1ec128-0f8a-43c7-8e0f-513883f82a61");

    public Plugin(
        IApplicationPaths applicationPaths,
        IXmlSerializer xmlSerializer)
        : base(applicationPaths, xmlSerializer)
    {
        Instance = this;
    }

    public static Plugin? Instance { get; private set; }

    public override string Name => "Vorschlagsboard";

    public override string Description =>
        "Vorschläge erstellen, abstimmen und administrieren.";

    public override Guid Id => PluginId;

    public IEnumerable<PluginPageInfo> GetPages()
    {
        yield return new PluginPageInfo
        {
            Name = "SuggestionBoard",
            DisplayName = "Vorschlagsboard",
            EmbeddedResourcePath =
                "Jellyfin.Plugin.SuggestionBoard.Web.config.html"
        };
    }
}
