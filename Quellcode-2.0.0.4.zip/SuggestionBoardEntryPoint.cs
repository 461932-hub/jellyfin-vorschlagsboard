using MediaBrowser.Common.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace Jellyfin.Plugin.SuggestionBoard;

public sealed class SuggestionBoardEntryPoint : IHostedService
{
    private readonly IApplicationPaths _applicationPaths;
    private readonly ILogger<SuggestionBoardEntryPoint> _logger;

    public SuggestionBoardEntryPoint(
        IApplicationPaths applicationPaths,
        ILogger<SuggestionBoardEntryPoint> logger)
    {
        _applicationPaths = applicationPaths;
        _logger = logger;
    }

    public Task StartAsync(CancellationToken cancellationToken)
    {
        WebInjectionMiddleware.WebIndexHtmlPath = LocateIndexHtml();

        if (WebInjectionMiddleware.WebIndexHtmlPath is { Length: > 0 } path)
        {
            _logger.LogInformation(
                "[Vorschlagsboard] Jellyfin-Web index.html gefunden: {Path}",
                path);
        }
        else
        {
            _logger.LogWarning(
                "[Vorschlagsboard] Jellyfin-Web index.html wurde nicht gefunden; " +
                "Board/API funktionieren, aber der obere Tab kann nicht injiziert werden.");
        }

        return Task.CompletedTask;
    }

    public Task StopAsync(CancellationToken cancellationToken)
        => Task.CompletedTask;

    private string? LocateIndexHtml()
    {
        string? webPath = null;

        try
        {
            webPath = _applicationPaths.WebPath;
        }
        catch
        {
            // Fallbacks unten.
        }

        var candidates = new[]
        {
            webPath,
            "/jellyfin/jellyfin-web",
            "/usr/share/jellyfin/web",
            "/usr/lib/jellyfin/web",
            "/app/jellyfin/jellyfin-web"
        };

        foreach (var directory in candidates)
        {
            if (string.IsNullOrWhiteSpace(directory))
            {
                continue;
            }

            var path = Path.Combine(directory, "index.html");
            if (File.Exists(path))
            {
                return path;
            }
        }

        return null;
    }
}
