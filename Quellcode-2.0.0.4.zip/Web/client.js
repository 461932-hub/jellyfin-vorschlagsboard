(() => {
    'use strict';
    if (window.__suggestionBoardNativeTabV4) return;
    window.__suggestionBoardNativeTabV4 = true;

    const TAB_ID = 'suggestionBoardNativeTab';
    const PAGE_ID = 'suggestionBoardNativePage';
    const STYLE_ID = 'suggestionBoardNativeStyle';
    const DRAWER_ID = 'suggestionBoardDrawerLink';
    const DRAWER_ITEM_ID = 'suggestionBoardDrawerItem';
    const LABEL = 'Vorschlagsboard';
    // The native authenticated route owns layout, navigation and history.
    const BOARD_HASH = '#/home?tab=0&suggestionBoard=1';
    let host = null;
    let scheduled = false;
    let lastBoardUrl = null;
    let resizeObserver = null;
    let observedHeader = null;
    let previousSession = null;

    const inCinema = () => document.documentElement.hasAttribute('data-cinema-inline-board');
    const route = () => {
        try { return new URL(location.hash.slice(1) || '/home', location.origin); }
        catch (_) { return null; }
    };
    const isBoardRoute = () => {
        const current = route();
        return current?.pathname === '/home' && current.searchParams.get('suggestionBoard') === '1';
    };
    const session = () => {
        const current = route();
        if (!current || /^\/(login|selectserver|addserver|forgotpassword|wizard)/i.test(current.pathname)) return null;
        try {
            const api = window.ApiClient;
            const token = api?.accessToken?.();
            const user = api?.getCurrentUserId?.();
            return token && user ? { api, token, user } : null;
        } catch (_) { return null; }
    };
    const text = element => (element.textContent || element.getAttribute('aria-label') || '')
        .replace(/\s+/g, ' ').trim();
    const visible = element => {
        const r = element.getBoundingClientRect();
        return r.width > 10 && r.height > 10;
    };
    const findNav = () => {
        for (const header of document.querySelectorAll('header, .MuiAppBar-root, .skinHeader')) {
            for (const source of header.querySelectorAll('a,button')) {
                if (!/^(Favoriten|Favorites|Startseite|Home)$/i.test(text(source)) || !visible(source)) continue;
                const parent = source.parentElement;
                if (!parent) continue;
                // Jellyfin 12.4 renders Favorites and libraries as siblings.
                const links = Array.from(parent.children).filter(node => node.matches('a,button'));
                if (links.length >= 2) return { parent, source, header };
                const slider = source.closest('.emby-tabs-slider');
                if (slider) return { parent: slider, source, header };
            }
        }
        return null;
    };
    const findDrawerNav = () => {
        for (const drawer of document.querySelectorAll('.MuiDrawer-paper')) {
            const source = Array.from(drawer.querySelectorAll('a.MuiListItemButton-root[href]')).find(link => {
                try {
                    const url = new URL(link.href, location.href);
                    const current = new URL(url.hash.slice(1), location.origin);
                    return url.origin === location.origin && current.pathname === '/home'
                        && (!current.searchParams.has('tab') || current.searchParams.get('tab') === '0');
                } catch (_) { return false; }
            });
            if (!source) continue;
            const parent = drawer.querySelector('#libraries-subheader')?.closest('.MuiList-root')
                || source.closest('.MuiList-root');
            if (parent) return { parent, source };
        }
        return null;
    };
    const setActive = (tab, active) => {
        if (!tab) return;
        if (tab.classList.contains('sb-native-tab-active') !== active) {
            tab.classList.toggle('sb-native-tab-active', active);
        }
        if (active && tab.getAttribute('aria-current') !== 'page') tab.setAttribute('aria-current', 'page');
        if (!active && tab.hasAttribute('aria-current')) tab.removeAttribute('aria-current');
    };
    const bindNavigation = (link, drawer = false) => link.addEventListener('click', event => {
        // Legacy Cinema owns its separate view. React's drawer presentation
        // wrapper must still receive mobile clicks so its original onClose runs.
        if (inCinema()) return;
        if (event.button !== 0 || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
        event.preventDefault();
        if (!drawer) event.stopPropagation();
        if (!isBoardRoute()) location.hash = BOARD_HASH;
        schedule();
    });
    const makeTab = source => {
        const tab = source.cloneNode(true);
        tab.id = TAB_ID;
        tab.textContent = LABEL;
        tab.setAttribute('aria-label', LABEL);
        for (const name of ['target', 'rel', 'aria-current', 'aria-selected', 'data-index']) tab.removeAttribute(name);
        tab.classList.remove('Mui-selected', 'MuiButton-colorPrimary', 'MuiButton-textPrimary', 'emby-tab-button-active');
        tab.style.color = 'inherit';
        if (tab.tagName === 'A') {
            tab.href = BOARD_HASH;
            tab.removeAttribute('role');
        } else tab.type = 'button';
        bindNavigation(tab);
        return tab;
    };
    const makeDrawerItem = source => {
        const item = document.createElement('li');
        item.id = DRAWER_ITEM_ID;
        item.className = source.closest('.MuiListItem-root')?.className || 'MuiListItem-root';
        const link = source.cloneNode(true);
        for (const node of [link, ...link.querySelectorAll('[id]')]) node.removeAttribute('id');
        link.id = DRAWER_ID;
        link.href = BOARD_HASH;
        link.setAttribute('aria-label', LABEL);
        for (const key of ['target', 'rel', 'aria-current', 'aria-selected', 'aria-describedby']) link.removeAttribute(key);
        link.classList.remove('Mui-selected');
        const label = link.querySelector('.MuiListItemText-primary') || link.querySelector('.MuiListItemText-root');
        if (label) label.textContent = LABEL;
        else link.textContent = LABEL;
        const icon = link.querySelector('.MuiListItemIcon-root');
        if (icon) {
            const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
            svg.setAttribute('viewBox', '0 0 24 24'); svg.setAttribute('width', '24'); svg.setAttribute('height', '24');
            svg.setAttribute('aria-hidden', 'true'); svg.setAttribute('fill', 'currentColor');
            const path = document.createElementNS(svg.namespaceURI, 'path');
            path.setAttribute('d', 'M4 3h16a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H8l-6 4V5a2 2 0 0 1 2-2zm2 4v2h12V7H6zm0 4v2h12v-2H6z');
            svg.append(path); icon.replaceChildren(svg);
        }
        bindNavigation(link, true);
        item.append(link);
        return item;
    };
    const setDrawerActive = active => {
        const link = document.getElementById(DRAWER_ID);
        if (!link) return;
        setActive(link, active);
        if (link.classList.contains('sb-native-drawer-active') !== active) link.classList.toggle('sb-native-drawer-active', active);
    };
    const boardUrl = () => {
        try {
            if (typeof window.ApiClient?.getUrl === 'function') {
                return window.ApiClient.getUrl('SuggestionBoard/Page?v=2.0.0.4');
            }
        } catch (_) { /* The native client may still be changing servers. */ }
        return new URL('../SuggestionBoard/Page?v=2.0.0.4', document.baseURI).href;
    };
    const clearHost = () => {
        host?.removeAttribute('data-sb-native-board-host');
        host = null;
        document.documentElement.removeAttribute('data-sb-native-board-open');
    };
    const hidePage = (discard = false) => {
        clearHost();
        const page = document.getElementById(PAGE_ID);
        if (discard) {
            page?.remove();
            lastBoardUrl = null;
        } else if (page && !page.hidden) page.hidden = true;
    };
    const findHost = () => document.querySelector('main') || document.querySelector('.mainAnimatedPages');
    const ensurePage = target => {
        let page = document.getElementById(PAGE_ID);
        if (!page) {
            page = document.createElement('section');
            page.id = PAGE_ID;
            page.hidden = true;
            page.setAttribute('aria-label', LABEL);
            const frame = document.createElement('iframe');
            frame.title = LABEL;
            frame.setAttribute('scrolling', 'auto');
            frame.referrerPolicy = 'no-referrer';
            page.appendChild(frame);
        }
        // Only our section is appended; native React children stay untouched.
        if (page.parentElement !== target) target.appendChild(page);
        const src = boardUrl();
        const frame = page.querySelector('iframe');
        if (src !== lastBoardUrl || !frame.hasAttribute('src')) {
            frame.src = src;
            lastBoardUrl = src;
        }
        return page;
    };
    const measure = header => {
        const bottom = Math.max(0, Math.round(header?.getBoundingClientRect().bottom || 64));
        const gutter = window.innerWidth <= 600 ? 24 : 40;
        const value = `${Math.max(240, Math.round(window.innerHeight - bottom - gutter))}px`;
        if (document.documentElement.style.getPropertyValue('--sb-page-min-height') !== value) {
            document.documentElement.style.setProperty('--sb-page-min-height', value);
        }
        if (observedHeader !== header && window.ResizeObserver) {
            resizeObserver?.disconnect();
            resizeObserver = new ResizeObserver(schedule);
            if (header) resizeObserver.observe(header);
            observedHeader = header;
        }
    };
    function sync() {
        scheduled = false;
        let tab = document.getElementById(TAB_ID);
        const auth = session();
        if (!auth) {
            previousSession = null;
            tab?.remove(); document.getElementById(DRAWER_ITEM_ID)?.remove();
            hidePage(true);
            return;
        }
        if (previousSession && (auth.api !== previousSession.api || auth.user !== previousSession.user || auth.token !== previousSession.token)) hidePage(true);
        previousSession = auth;
        if (inCinema()) {
            setActive(tab, false);
            document.getElementById(DRAWER_ITEM_ID)?.remove();
            hidePage();
            return;
        }
        const native = findNav();
        if (native) {
            if (!tab) tab = makeTab(native.source);
            // Libraries can arrive asynchronously or be reordered by React.
            if (tab.parentElement !== native.parent || native.parent.lastElementChild !== tab) native.parent.appendChild(tab);
        } else {
            tab?.remove();
            tab = null;
        }
        const drawer = findDrawerNav();
        if (drawer) {
            let item = document.getElementById(DRAWER_ITEM_ID);
            if (!item) item = makeDrawerItem(drawer.source);
            if (item.parentElement !== drawer.parent || drawer.parent.lastElementChild !== item) drawer.parent.appendChild(item);
        }
        const active = isBoardRoute() && !inCinema();
        setActive(tab, active);
        setDrawerActive(active);
        if (!active) {
            hidePage();
            return;
        }
        const target = findHost();
        if (!target) return;
        if (host && host !== target) clearHost();
        host = target;
        const page = ensurePage(host);
        if (!host.hasAttribute('data-sb-native-board-host')) host.setAttribute('data-sb-native-board-host', '');
        if (!document.documentElement.hasAttribute('data-sb-native-board-open')) {
            document.documentElement.setAttribute('data-sb-native-board-open', '');
        }
        if (page.hidden) page.hidden = false;
        measure(native?.header || document.querySelector('header.MuiAppBar-root,.skinHeader'));
        // The board owns this authenticated route even when the closed drawer
        // is the only navigation. Do not leave the optional Cinema boot cover up.
        window.__nativeCinemaReady?.();
    }
    function schedule() {
        if (!scheduled) {
            scheduled = true;
            requestAnimationFrame(sync);
        }
    }

    document.getElementById(STYLE_ID)?.remove();
    const style = document.createElement('style');
    style.id = STYLE_ID;
    style.textContent = `
        #${TAB_ID} { flex: 0 0 auto; white-space: nowrap; }
        #${TAB_ID}.sb-native-tab-active {
            color: var(--mui-palette-primary-main, var(--theme-primary-color, #00a4dc)) !important;
            opacity: 1 !important;
        }
        #${DRAWER_ID}.sb-native-drawer-active {
            color: var(--jf-palette-primary-main, #e50914) !important;
            background: #e5091429 !important;
        }
        #${DRAWER_ID}.sb-native-drawer-active .MuiListItemIcon-root { color: inherit; }
        [data-sb-native-board-host] { min-height: 0 !important; overflow: auto !important; }
        main[data-sb-native-board-host] { display: flex; flex-direction: column; }
        [data-sb-native-board-host] > :not(#${PAGE_ID}) { display: none !important; }
        #${PAGE_ID} {
            position: relative; box-sizing: border-box; width: calc(100% - 48px); flex: 0 0 auto;
            max-width: 1440px; margin: 20px auto; border: 1px solid #ffffff14;
            border-radius: 18px; overflow: hidden;
            min-height: var(--sb-page-min-height, calc(100dvh - 64px)); background: #101010;
        }
        #${PAGE_ID}[hidden] { display: none !important; }
        #${PAGE_ID} iframe {
            display: block; width: 100%; border: 0;
            min-height: var(--sb-page-min-height, calc(100dvh - 64px)); background: #101010;
        }
        @media (max-width: 600px) {
            #${PAGE_ID} { width: calc(100% - 24px); margin: 12px auto; border-radius: 14px; }
        }
    `;
    document.head.appendChild(style);
    for (const event of ['hashchange', 'popstate', 'resize']) window.addEventListener(event, schedule);
    for (const event of ['viewshow', 'pageshow']) document.addEventListener(event, schedule);
    // React Router can push history without firing hashchange. Preserve all
    // native arguments, receiver, return values and errors; only schedule sync.
    for (const method of ['pushState', 'replaceState']) {
        const original = history[method];
        history[method] = function (...args) {
            const result = Reflect.apply(original, this, args);
            schedule();
            return result;
        };
    }
    const observer = new MutationObserver(schedule);
    observer.observe(document.documentElement, {
        childList: true, subtree: true, attributes: true,
        attributeFilter: ['class', 'data-cinema-inline-board']
    });
    schedule();
    console.info('[Vorschlagsboard] Seitennavigation 2.0.0.4 aktiv.');
})();
