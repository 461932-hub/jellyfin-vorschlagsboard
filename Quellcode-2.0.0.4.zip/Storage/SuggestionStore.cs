using System.Text;
using System.Text.Json;
using Jellyfin.Plugin.SuggestionBoard.Models;
using MediaBrowser.Common.Configuration;
using Microsoft.Extensions.Logging;

namespace Jellyfin.Plugin.SuggestionBoard.Storage;

public sealed class BoardStoreException(int statusCode, string message) : Exception(message)
{
    public int StatusCode { get; } = statusCode;
}

public sealed class SuggestionStore
{
    public const int MaxItems = 2000, MaxPerUser = 100, MaxVoters = 512;
    private const int MaxLegacyItems = 20000, MaxRecordBytes = 262144;
    private readonly SemaphoreSlim _gate = new(1, 1);
    private readonly string _legacyPath, _directory;
    private Dictionary<Guid, SuggestionRecord>? _items;
    private bool _loadFailed;
    private long _totalBytes;
    private readonly ILogger<SuggestionStore>? _logger;
    private SuggestionRecord[]? _newest, _popular;
    private static readonly JsonSerializerOptions JsonOptions = new() { PropertyNamingPolicy = JsonNamingPolicy.CamelCase, WriteIndented = true, MaxDepth = 16 };
    public SuggestionStore(IApplicationPaths paths, ILogger<SuggestionStore>? logger = null)
    {
        _logger = logger;
        var root = Path.Combine(paths.PluginConfigurationsPath, "Jellyfin.Plugin.SuggestionBoardV2");
        Directory.CreateDirectory(root);
        _legacyPath = Path.Combine(root, "suggestions.json"); _directory = Path.Combine(root, "records-v3");
    }
    public async Task<IReadOnlyList<SuggestionRecord>> GetPageAsync(string? sort, int start, int limit, CancellationToken ct)
    {
        if (start < 0 || limit is < 1 or > 100) throw new BoardStoreException(400, "Ungültige Seitengröße.");
        await _gate.WaitAsync(ct).ConfigureAwait(false);
        try
        {
            await EnsureLoaded(ct).ConfigureAwait(false);
            _newest ??= _items!.Values.OrderBy(x => x.IsClosed).ThenByDescending(x => x.CreatedAtUtc).ThenBy(x => x.Id).ToArray();
            var popular = string.Equals(sort, "popular", StringComparison.OrdinalIgnoreCase);
            if (popular) _popular ??= _items!.Values.OrderBy(x => x.IsClosed).ThenByDescending(x => x.VoterKeys.Count).ThenByDescending(x => x.CreatedAtUtc).ThenBy(x => x.Id).ToArray();
            return (popular ? _popular! : _newest).Skip(start).Take(limit).ToArray();
        }
        finally { _gate.Release(); }
    }
    public async Task<SuggestionRecord> AddAsync(string title, string description, string name, string key, CancellationToken ct)
    {
        RequireUserKey(key);
        if (title.Length is < 2 or > 120 || description.Length is < 2 or > 4000) throw new BoardStoreException(400, "Ungültiger Vorschlag.");
        await _gate.WaitAsync(ct).ConfigureAwait(false);
        try
        {
            await EnsureLoaded(ct).ConfigureAwait(false);
            if (_items!.Count >= MaxItems) throw new BoardStoreException(409, "Das Board ist voll. Ein Administrator muss zunächst alte Vorschläge entfernen.");
            if (_items.Values.Count(x => x.CreatedByUserKey == key) >= MaxPerUser) throw new BoardStoreException(409, "Du hast das Kontingent von 100 Vorschlägen erreicht.");
            var item = new SuggestionRecord { IdentityVersion = 3, Id = Guid.NewGuid(), Title = title, Description = description, CreatedBy = name.Length <= 256 ? name : name[..256], CreatedByUserKey = key, CreatedAtUtc = DateTimeOffset.UtcNow };
            await Commit(item, ct).ConfigureAwait(false); return item;
        }
        finally { _gate.Release(); }
    }
    public async Task<SuggestionRecord?> ToggleVoteAsync(Guid id, string key, CancellationToken ct)
    {
        RequireUserKey(key); await _gate.WaitAsync(ct).ConfigureAwait(false);
        try
        {
            await EnsureLoaded(ct).ConfigureAwait(false);
            if (!_items!.TryGetValue(id, out var old) || old.IsClosed) return old;
            var item = Copy(old); var index = item.VoterKeys.FindIndex(x => x == key);
            if (index >= 0) item.VoterKeys.RemoveAt(index);
            else
            {
                if (item.VoterKeys.Count >= MaxVoters) throw new BoardStoreException(409, "Für diesen Vorschlag ist die maximale Stimmenzahl erreicht.");
                item.VoterKeys.Add(key);
            }
            await Commit(item, ct).ConfigureAwait(false); return item;
        }
        finally { _gate.Release(); }
    }
    public async Task<SuggestionRecord?> SetClosedAsync(Guid id, bool closed, CancellationToken ct)
    {
        await _gate.WaitAsync(ct).ConfigureAwait(false);
        try
        {
            await EnsureLoaded(ct).ConfigureAwait(false);
            if (!_items!.TryGetValue(id, out var old)) return null;
            if (old.IsClosed == closed) return old;
            var item = Copy(old); item.IsClosed = closed;
            await Commit(item, ct).ConfigureAwait(false); return item;
        }
        finally { _gate.Release(); }
    }
    public async Task<bool> DeleteAsync(Guid id, CancellationToken ct)
    {
        await _gate.WaitAsync(ct).ConfigureAwait(false);
        try
        {
            await EnsureLoaded(ct).ConfigureAwait(false);
            if (!_items!.ContainsKey(id)) return false;
            var path = RecordPath(_directory, id); var size = new FileInfo(path).Length;
            File.Delete(path); _totalBytes -= size; _items.Remove(id); Invalidate(); return true;
        }
        finally { _gate.Release(); }
    }
    private static string RecordPath(string directory, Guid id) => Path.Combine(directory, id.ToString("N") + ".json");
    private static void RequireUserKey(string key)
    {
        if (!key.StartsWith("user:", StringComparison.Ordinal) || !Guid.TryParseExact(key[5..], "N", out var id) || id == Guid.Empty)
            throw new BoardStoreException(403, "Eine persönliche Jellyfin-Anmeldung ist erforderlich.");
    }
    private static SuggestionRecord Copy(SuggestionRecord item) => new() { IdentityVersion = item.IdentityVersion, Id = item.Id, Title = item.Title, Description = item.Description, CreatedBy = item.CreatedBy, CreatedByUserKey = item.CreatedByUserKey, CreatedAtUtc = item.CreatedAtUtc, IsClosed = item.IsClosed, VoterKeys = new(item.VoterKeys) };
    private void Invalidate() { _newest = _popular = null; }
    private async Task Commit(SuggestionRecord item, CancellationToken ct)
    {
        var path = RecordPath(_directory, item.Id);
        var oldSize = File.Exists(path) ? new FileInfo(path).Length : 0;
        var newSize = JsonSerializer.SerializeToUtf8Bytes(item, JsonOptions).Length;
        if (_totalBytes - oldSize + newSize > 32L * 1024 * 1024) throw new BoardStoreException(409, "Das Speicherlimit des Boards ist erreicht.");
        await WriteRecord(_directory, item, ct).ConfigureAwait(false);
        _totalBytes = _totalBytes - oldSize + newSize; _items![item.Id] = item; Invalidate();
    }
    private static async Task WriteRecord(string directory, SuggestionRecord item, CancellationToken ct)
    {
        var bytes = JsonSerializer.SerializeToUtf8Bytes(item, JsonOptions);
        if (bytes.Length > MaxRecordBytes) throw new BoardStoreException(409, "Der Vorschlag überschreitet die Speichergrenze.");
        var target = RecordPath(directory, item.Id); var temp = target + ".tmp";
        try { await File.WriteAllBytesAsync(temp, bytes, ct).ConfigureAwait(false); await MoveWithRetry(() => File.Move(temp, target, overwrite: true), ct).ConfigureAwait(false); }
        finally { if (File.Exists(temp)) File.Delete(temp); }
    }
    private static async Task MoveWithRetry(Action move, CancellationToken ct)
    {
        // Antivirus/indexers can briefly hold new files on Windows. Retries are
        // bounded, cancellation-aware, and never replace failed data with defaults.
        for (var attempt = 0; ; attempt++)
        {
            ct.ThrowIfCancellationRequested();
            try { move(); return; }
            catch (Exception error) when (attempt < 3 && error is IOException or UnauthorizedAccessException)
            { await Task.Delay(40 * (attempt + 1), ct).ConfigureAwait(false); }
        }
    }
    private static string LegacyKey(string? key) => "legacy:" + Convert.ToBase64String(Encoding.UTF8.GetBytes(key ?? string.Empty));
    private static void Validate(SuggestionRecord item)
    {
        if (item.Id == Guid.Empty || item.Title is null || item.Description is null || item.CreatedBy is null || item.CreatedByUserKey is null || item.VoterKeys is null || item.VoterKeys.Any(x => x is null)) throw new JsonException("Invalid suggestion record.");
    }
    private async Task EnsureLoaded(CancellationToken ct)
    {
        if (_items is not null) return;
        if (_loadFailed) throw new BoardStoreException(503, "Die Board-Daten müssen vor einem Neustart geprüft werden.");
        try
        {
            if (!Directory.Exists(_directory)) await ImportLegacy(ct).ConfigureAwait(false);
            var items = new Dictionary<Guid, SuggestionRecord>(); long totalBytes = 0;
            foreach (var path in Directory.EnumerateFiles(_directory, "*.json"))
            {
                ct.ThrowIfCancellationRequested(); var size = new FileInfo(path).Length; totalBytes += size;
                if (items.Count >= MaxLegacyItems || size > MaxRecordBytes || totalBytes > 32L * 1024 * 1024) throw new JsonException("Storage limit exceeded.");
                await using var stream = File.OpenRead(path);
                var item = await JsonSerializer.DeserializeAsync<SuggestionRecord>(stream, JsonOptions, ct).ConfigureAwait(false) ?? throw new JsonException();
                Validate(item);
                if (item.IdentityVersion != 3 || Path.GetFileName(path) != item.Id.ToString("N") + ".json" || !items.TryAdd(item.Id, item)) throw new JsonException();
            }
            _items = items; _totalBytes = totalBytes;
        }
        catch (Exception error) when (error is JsonException or IOException or UnauthorizedAccessException or BoardStoreException)
        { _loadFailed = true; _logger?.LogError(error, "Vorschlagsboard: storage initialization failed; original data retained."); throw new BoardStoreException(503, "Die Board-Daten konnten nicht sicher geladen werden. Bitte die Datensicherung und Dateirechte prüfen."); }
    }
    private async Task ImportLegacy(CancellationToken ct)
    {
        var items = new List<SuggestionRecord>();
        if (File.Exists(_legacyPath))
        {
            if (new FileInfo(_legacyPath).Length > 32L * 1024 * 1024) throw new JsonException("Legacy data too large.");
            await using (var stream = File.OpenRead(_legacyPath)) items = await JsonSerializer.DeserializeAsync<List<SuggestionRecord>>(stream, JsonOptions, ct).ConfigureAwait(false) ?? throw new JsonException();
            if (items.Count > MaxLegacyItems || items.Any(x => x is null) || items.Select(x => x.Id).Distinct().Count() != items.Count) throw new JsonException();
            foreach (var item in items)
            {
                Validate(item);
                // Never assign legacy name-based votes to a possibly reassigned account.
                item.CreatedByUserKey = LegacyKey(item.CreatedByUserKey); item.VoterKeys = item.VoterKeys.Select(LegacyKey).ToList(); item.IdentityVersion = 3;
            }
        }
        var staging = _directory + ".import-" + Guid.NewGuid().ToString("N"); Directory.CreateDirectory(staging);
        try
        {
            long size = 0;
            foreach (var item in items)
            {
                size += JsonSerializer.SerializeToUtf8Bytes(item, JsonOptions).Length;
                if (size > 32L * 1024 * 1024) throw new JsonException("Migrated data too large.");
                await WriteRecord(staging, item, ct).ConfigureAwait(false);
            }
            if (File.Exists(_legacyPath)) File.Copy(_legacyPath, _legacyPath + ".before-v3-" + Guid.NewGuid().ToString("N") + ".bak");
            // Publish only a complete migration. Original JSON is kept unchanged.
            await MoveWithRetry(() => Directory.Move(staging, _directory), ct).ConfigureAwait(false);
        }
        finally { if (Directory.Exists(staging)) Directory.Delete(staging, recursive: true); }
    }
}
