namespace Jellyfin.Plugin.SuggestionBoard.Models;

public sealed class SuggestionRecord
{
    public int IdentityVersion { get; set; }
    public Guid Id { get; set; } = Guid.NewGuid();

    public string Title { get; set; } = string.Empty;

    public string Description { get; set; } = string.Empty;

    public string CreatedBy { get; set; } = string.Empty;

    public string CreatedByUserKey { get; set; } = string.Empty;

    public DateTimeOffset CreatedAtUtc { get; set; } =
        DateTimeOffset.UtcNow;

    public bool IsClosed { get; set; }

    public List<string> VoterKeys { get; set; } = new();
}

public sealed class SuggestionResponse
{
    public Guid Id { get; set; }

    public string Title { get; set; } = string.Empty;

    public string Description { get; set; } = string.Empty;

    public string CreatedBy { get; set; } = string.Empty;

    public DateTimeOffset CreatedAtUtc { get; set; }

    public bool IsClosed { get; set; }

    public int VoteCount { get; set; }

    public bool HasVoted { get; set; }

    public bool IsOwnSuggestion { get; set; }
}

public sealed class CreateSuggestionRequest
{
    public string Title { get; set; } = string.Empty;

    public string Description { get; set; } = string.Empty;
}

public sealed class SetSuggestionStatusRequest
{
    public bool IsClosed { get; set; }
}
