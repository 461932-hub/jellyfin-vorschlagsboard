using System.Security.Cryptography;
using System.Text;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Features;

namespace Jellyfin.Plugin.SuggestionBoard;

public sealed class WebInjectionMiddleware
{
    private const string Marker =
        "data-suggestion-board-client=\"2.0.0.4\"";

    private readonly RequestDelegate _next;

    public static volatile string? WebIndexHtmlPath;

    public WebInjectionMiddleware(RequestDelegate next)
    {
        _next = next;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        if (!ShouldTransform(context.Request))
        {
            await _next(context).ConfigureAwait(false);
            return;
        }

        context.Request.Headers.Remove("Accept-Encoding");

        var path = context.Request.Path.Value ?? string.Empty;
        var directServe =
            path.EndsWith("/web/index.html", StringComparison.OrdinalIgnoreCase)
            || path.EndsWith("/web/", StringComparison.OrdinalIgnoreCase);

        var indexPath = WebIndexHtmlPath;

        if (
            directServe
            && indexPath is not null
            && (HttpMethods.IsGet(context.Request.Method)
                || HttpMethods.IsHead(context.Request.Method)))
        {
            try
            {
                var html = await File.ReadAllTextAsync(indexPath)
                    .ConfigureAwait(false);

                if (html.Contains("</body>", StringComparison.OrdinalIgnoreCase))
                {
                    var transformed = InjectClientLoader(html);
                    var bytes = Encoding.UTF8.GetBytes(transformed);
                    var hash = Convert.ToHexString(SHA1.HashData(bytes));
                    var etag = "\"sb-" + hash[..20] + "\"";

                    context.Response.Headers.Remove("Last-Modified");
                    context.Response.Headers["ETag"] = etag;
                    context.Response.Headers["Cache-Control"] = "no-cache";

                    if (
                        context.Request.Headers.TryGetValue("If-None-Match", out var inm)
                        && inm.ToString().Contains(etag, StringComparison.Ordinal))
                    {
                        context.Response.StatusCode = StatusCodes.Status304NotModified;
                        return;
                    }

                    context.Response.StatusCode = StatusCodes.Status200OK;
                    context.Response.ContentType = "text/html; charset=utf-8";
                    context.Response.ContentLength = bytes.Length;

                    if (HttpMethods.IsHead(context.Request.Method))
                    {
                        return;
                    }

                    await context.Response.Body.WriteAsync(bytes)
                        .ConfigureAwait(false);
                    return;
                }
            }
            catch
            {
                // Capture-Fallback unten.
            }
        }

        var originalBodyFeature =
            context.Features.Get<IHttpResponseBodyFeature>();

        using var buffer = new MemoryStream();
        context.Features.Set<IHttpResponseBodyFeature>(
            new StreamResponseBodyFeature(buffer));

        try
        {
            await _next(context).ConfigureAwait(false);
        }
        finally
        {
            context.Features.Set(originalBodyFeature);
        }

        var originalBytes = buffer.ToArray();

        if (
            context.Response.StatusCode != StatusCodes.Status200OK
            || originalBytes.Length == 0
            || !(context.Response.ContentType?.StartsWith(
                    "text/html",
                    StringComparison.OrdinalIgnoreCase) ?? false))
        {
            if (originalBytes.Length > 0)
            {
                context.Response.ContentLength = originalBytes.Length;
                await context.Response.Body.WriteAsync(originalBytes)
                    .ConfigureAwait(false);
            }

            return;
        }

        var htmlText = Encoding.UTF8.GetString(originalBytes);
        var output = InjectClientLoader(htmlText);
        var outputBytes = Encoding.UTF8.GetBytes(output);

        context.Response.Headers.Remove("ETag");
        context.Response.Headers.Remove("Last-Modified");
        context.Response.Headers.Remove("Content-Encoding");
        context.Response.Headers["Cache-Control"] =
            "no-cache, no-store, must-revalidate";
        context.Response.ContentLength = outputBytes.Length;

        await context.Response.Body.WriteAsync(outputBytes)
            .ConfigureAwait(false);
    }

    private static bool ShouldTransform(HttpRequest request)
    {
        if (
            !HttpMethods.IsGet(request.Method)
            && !HttpMethods.IsHead(request.Method))
        {
            return false;
        }

        var path = request.Path.Value ?? string.Empty;

        return path.EndsWith("/web/index.html", StringComparison.OrdinalIgnoreCase)
               || path.EndsWith("/web/", StringComparison.OrdinalIgnoreCase)
               || path.Equals("/web", StringComparison.OrdinalIgnoreCase);
    }

    private static string InjectClientLoader(string html)
    {
        html = StripOldLoader(html);

        if (html.Contains(Marker, StringComparison.Ordinal))
        {
            return html;
        }

        const string loader = """
<script id="suggestion-board-client-loader" data-suggestion-board-client="2.0.0.4">
(function () {
    if (window.__suggestionBoardLoaderV2) return;
    window.__suggestionBoardLoaderV2 = true;
    try {
        var src = new URL('../SuggestionBoard/client.js?v=2.0.0.4', document.baseURI).href;
        var script = document.createElement('script');
        script.src = src;
        script.defer = true;
        script.dataset.suggestionBoardRuntime = '2.0.0.4';
        document.head.appendChild(script);
    } catch (error) {
        console.error('[Vorschlagsboard] Loader:', error);
    }
}());
</script>
""";

        var bodyIndex = html.LastIndexOf(
            "</body>",
            StringComparison.OrdinalIgnoreCase);

        return bodyIndex >= 0
            ? html.Insert(bodyIndex, loader)
            : html + loader;
    }

    private static string StripOldLoader(string html)
    {
        const string start =
            "<script id=\"suggestion-board-client-loader\"";

        var index = html.IndexOf(
            start,
            StringComparison.OrdinalIgnoreCase);

        while (index >= 0)
        {
            var end = html.IndexOf(
                "</script>",
                index,
                StringComparison.OrdinalIgnoreCase);

            if (end < 0)
            {
                break;
            }

            end += "</script>".Length;
            html = html.Remove(index, end - index);
            index = html.IndexOf(
                start,
                StringComparison.OrdinalIgnoreCase);
        }

        return html;
    }
}
